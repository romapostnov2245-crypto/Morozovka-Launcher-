package com.myproject.launcher

object Config {
    const val SERVER_NAME = "Морозовка"
    const val SERVER_IP = "188.127.241.74"
    const val SERVER_PORT = 2298

    // Пакет установленного клиента игры. Поменяй, когда узнаешь точный.
    const val GAME_PACKAGE = "com.morozovka.game"

    // Необязательно: ссылка на config.json с новостями и файлами для скачивания.
    // Оставь пустой строкой, если пока нет.
    const val CONFIG_URL = ""
}
