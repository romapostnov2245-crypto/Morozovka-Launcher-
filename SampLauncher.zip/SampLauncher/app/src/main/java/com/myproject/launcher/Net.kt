package com.myproject.launcher

import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.nio.charset.Charset
import java.security.MessageDigest

data class ServerInfo(val players: Int, val max: Int, val name: String, val ping: Int)

object Net {
    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 15000
        return c
    }

    fun get(url: String): String =
        open(url).inputStream.bufferedReader().use { it.readText() }

    fun md5(f: File): String {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().use { ins ->
            val b = ByteArray(8192)
            while (true) {
                val n = ins.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val c = open(url)
        val total = c.contentLengthLong
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        c.inputStream.use { i ->
            tmp.outputStream().use { o ->
                val b = ByteArray(16384)
                var done = 0L
                while (true) {
                    val n = i.read(b)
                    if (n < 0) break
                    o.write(b, 0, n)
                    done += n
                    onProgress(done, total)
                }
            }
        }
        if (dest.exists()) dest.delete()
        tmp.renameTo(dest)
    }

    /** Запрос к серверу SA:MP: онлайн, слоты, название, пинг. null если сервер не ответил. */
    fun query(host: String, port: Int): ServerInfo? = try {
        val addr = InetAddress.getByName(host)
        val ip = addr.address
        val req = byteArrayOf('S'.code.toByte(), 'A'.code.toByte(), 'M'.code.toByte(), 'P'.code.toByte()) +
                ip + byteArrayOf((port and 0xFF).toByte(), (port shr 8 and 0xFF).toByte(), 'i'.code.toByte())
        DatagramSocket().use { s ->
            s.soTimeout = 2500
            val t0 = System.nanoTime()
            s.send(DatagramPacket(req, req.size, addr, port))
            val buf = ByteArray(1024)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            val ping = ((System.nanoTime() - t0) / 1_000_000).toInt()
            fun u8(i: Int) = buf[i].toInt() and 0xFF
            val players = u8(12) or (u8(13) shl 8)
            val max = u8(14) or (u8(15) shl 8)
            var name = ""
            if (p.length >= 20) {
                val len = u8(16) or (u8(17) shl 8) or (u8(18) shl 16) or (u8(19) shl 24)
                if (len in 0..(p.length - 20)) name = String(buf, 20, len, Charset.forName("windows-1251"))
            }
            ServerInfo(players, max, name, ping)
        }
    } catch (e: Exception) { null }
}
