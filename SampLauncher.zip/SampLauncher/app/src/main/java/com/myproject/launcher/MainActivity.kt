package com.myproject.launcher

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private val BG = 0xFF0A1020.toInt()
    private val CARD = 0xFF121B30.toInt()
    private val STROKE = 0xFF1E2C4A.toInt()
    private val ACCENT = 0xFF4FC3F7.toInt()
    private val TEXT2 = 0xFF8FA0BF.toInt()

    private lateinit var onlineTv: TextView
    private lateinit var nameTv: TextView
    private lateinit var pingTv: TextView
    private lateinit var fill: ProgressBar
    private lateinit var newsBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var nick: EditText
    private lateinit var play: Button
    @Volatile private var alive = true
    private var cfg: JSONObject? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(CARD, 16, STROKE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(44), dp(18), dp(12))
        }
        content.addView(tv(Config.SERVER_NAME.uppercase(), 32f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.2f
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(tv("SA:MP  •  ${Config.SERVER_IP}:${Config.SERVER_PORT}", 12f, ACCENT).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))

        val sc = card().apply { (layoutParams as LinearLayout.LayoutParams).topMargin = dp(22) }
        nameTv = tv(Config.SERVER_NAME, 14f, TEXT2)
        onlineTv = tv("…", 30f, Color.WHITE, true)
        fill = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(STROKE)
        }
        pingTv = tv("Пинг: —", 12f, TEXT2)
        sc.addView(nameTv); sc.addView(onlineTv)
        sc.addView(fill, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(6) })
        sc.addView(pingTv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        content.addView(sc)

        content.addView(tv("НОВОСТИ", 12f, ACCENT, true).apply { letterSpacing = 0.15f },
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        newsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(newsBox)

        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(18))
            setBackgroundColor(0xFF0D1528.toInt())
        }
        nick = EditText(this).apply {
            hint = "Ник (Name_Surname)"
            setHintTextColor(0xFF5C6B8A.toInt()); setTextColor(Color.WHITE)
            setSingleLine(true)
            background = bg(CARD, 12, STROKE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setText(getPreferences(MODE_PRIVATE).getString("nick", ""))
        }
        bottom.addView(nick, LinearLayout.LayoutParams(-1, -2))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(STROKE)
        }
        bottom.addView(bar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(12) })
        status = tv("Готов к запуску", 12f, TEXT2)
        bottom.addView(status, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        play = Button(this).apply {
            text = "ИГРАТЬ"; textSize = 18f; isAllCaps = false
            setTypeface(null, Typeface.BOLD); setTextColor(0xFF06101F.toInt())
            background = bg(ACCENT, 14)
            setOnClickListener { onPlay() }
        }
        bottom.addView(play, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) })
        root.addView(bottom)

        setContentView(root)
        showNews(listOf("Добро пожаловать!" to "Рады видеть тебя на проекте ${Config.SERVER_NAME}. Введи ник и жми «Играть»."))
        loadConfig()
        startPolling()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }

    private fun ui(f: () -> Unit) = runOnUiThread(f)

    private fun showNews(items: List<Pair<String, String>>) {
        newsBox.removeAllViews()
        for ((t, b) in items) {
            val c = card()
            c.addView(tv(t, 15f, Color.WHITE, true))
            if (b.isNotBlank()) c.addView(tv(b, 13f, TEXT2), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
            newsBox.addView(c)
        }
    }

    private fun startPolling() = Thread {
        while (alive) {
            val info = Net.query(Config.SERVER_IP, Config.SERVER_PORT)
            ui {
                if (info != null) {
                    onlineTv.text = "${info.players} / ${info.max}"
                    onlineTv.setTextColor(Color.WHITE)
                    fill.max = maxOf(info.max, 1); fill.progress = info.players
                    pingTv.text = "Пинг: ${info.ping} мс"
                    nameTv.text = info.name.ifBlank { Config.SERVER_NAME }
                } else {
                    onlineTv.text = "Офлайн"
                    onlineTv.setTextColor(0xFFEF5350.toInt())
                    fill.progress = 0; pingTv.text = "Сервер не отвечает"
                }
            }
            try { Thread.sleep(10000) } catch (e: InterruptedException) { break }
        }
    }.start()

    private fun loadConfig() {
        if (Config.CONFIG_URL.isBlank()) return
        Thread {
            try {
                val c = JSONObject(Net.get(Config.CONFIG_URL)); cfg = c
                val arr = c.optJSONArray("news")
                if (arr != null && arr.length() > 0) {
                    val list = (0 until arr.length()).map {
                        val n = arr.getJSONObject(it); n.optString("title") to n.optString("text")
                    }
                    ui { showNews(list) }
                }
            } catch (e: Exception) { ui { status.text = "Новости недоступны" } }
        }.start()
    }

    private fun onPlay() {
        val name = nick.text.toString().trim()
        if (name.length < 3) { status.text = "Введи ник (минимум 3 символа)"; return }
        getPreferences(MODE_PRIVATE).edit().putString("nick", name).apply()
        play.isEnabled = false
        Thread {
            try {
                val base = getExternalFilesDir(null)!!
                val files = cfg?.optJSONArray("files")
                if (files != null) for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    val dest = File(base, f.getString("path"))
                    val md5 = f.optString("md5")
                    if (dest.exists() && (md5.isEmpty() || Net.md5(dest).equals(md5, true))) continue
                    ui { status.text = "Скачивание ${i + 1}/${files.length()}: ${f.getString("path")}" }
                    Net.download(f.getString("url"), dest) { d, t ->
                        if (t > 0) ui { bar.progress = (d * 100 / t).toInt() }
                    }
                }
                ui { bar.progress = 100; launch(name) }
            } catch (e: Exception) {
                ui { status.text = "Ошибка: ${e.message}" }
            }
            ui { play.isEnabled = true }
        }.start()
    }

    private fun launch(name: String) {
        val i = packageManager.getLaunchIntentForPackage(Config.GAME_PACKAGE)
        if (i == null) { status.text = "Клиент игры не установлен"; return }
        status.text = "Запуск..."
        i.putExtra("nickname", name)
        i.putExtra("ip", Config.SERVER_IP)
        i.putExtra("port", Config.SERVER_PORT)
        startActivity(i)
    }
}
